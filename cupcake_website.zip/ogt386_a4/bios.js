onload=async function(){
	
	// CORS is a security system that breaks JS for local files
	// const requestOptions = {
    //         mode: "no-cors"
    //     };
	

	// the ideal way to call JSON
	// const request = await this.fetch("./items.json", requestOptions);
	// const shop_items = await request.json();
	
	// the workaround. yes, the json is a single line. no, there is nothing I can do about it.
	// WHY IS CAKES.PNG A JPG FILE????????????????????
	const biographies = JSON.parse('{"bios":[ {"name":"Lorem Ipsum", "desc":"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras porta leo eget ipsum consectetur congue. Aenean cursus volutpat lacus, ac convallis magna efficitur ac. Maecenas lorem magna, aliquet ut congue id, congue a ligula. Ut diam orci, molestie venenatis eleifend ut, euismod a lacus. Sed erat ipsum, mattis in condimentum at, rutrum tristique purus. Integer ac velit vitae ipsum fermentum molestie. Duis consectetur in sem et lacinia. ", "picture":"images/person.jpg"}, {"name":"Lorem Ipsum", "desc":"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras porta leo eget ipsum consectetur congue. Aenean cursus volutpat lacus, ac convallis magna efficitur ac. Maecenas lorem magna, aliquet ut congue id, congue a ligula. Ut diam orci, molestie venenatis eleifend ut, euismod a lacus. Sed erat ipsum, mattis in condimentum at, rutrum tristique purus. Integer ac velit vitae ipsum fermentum molestie. Duis consectetur in sem et lacinia. ", "picture":"images/person.jpg"} ]}');

    
	let container = document.getElementById("container");
    for(let bio of biographies.bios){
		let main = document.createElement("div");
		let entry = document.createElement("div");
		
        let name = document.createElement("h1");
        let desc = document.createElement("p");
		
		let picture = document.createElement("img");
		
		main.id = "main";
		
		entry.id = "mainFive";
		
        name.innerHTML = bio.name;
		name.className = "picHead";
		name.id = "aboutHead";
		
		desc.innerHTML = bio.desc;
		desc.className = "paragraph";
		desc.id = "longBio";
		
		picture.setAttribute('src', bio.picture);
		picture.alt = "Pinkest Power";
		picture.id = "bio";
		
		main.appendChild(picture)
		
		entry.appendChild(name);
		entry.appendChild(desc);
		main.appendChild(entry);
		
		container.appendChild(main);
		
		
		

    };
}