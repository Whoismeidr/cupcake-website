document.getElementById("submit").addEventListener('click', function(){

			let result_output = document.getElementById("result");
	
			result_output.innerText = "Submitted";
			
			
		});