onload=async function(){
	
	// CORS is a security system that breaks JS for local files
	// const requestOptions = {
    //         mode: "no-cors"
    //     };
	

	// the ideal way to call JSON
	// const request = await this.fetch("./items.json", requestOptions);
	// const shop_items = await request.json();
	
	// the workaround. yes, thie json is a single line. no, there is nothing I can do about it.
	// WHY IS CAKES.PNG A JPG FILE????????????????????
	 const shop_items = JSON.parse('{"items":[ {"name":"Lorem Ipsum", "desc":"Lorem Ipsum", "desc2":"Lorem Ipsum", "price":"Lorem Ipsum", "picture":"images/cakes.jpg"}, {"name":"Lorem Ipsum", "desc":"Lorem Ipsum", "desc2":"Lorem Ipsum", "price":"Lorem Ipsum", "picture":"images/cakes.jpg"}, {"name":"Lorem Ipsum", "desc":"Lorem Ipsum", "desc2":"Lorem Ipsum", "price":"Lorem Ipsum", "picture":"images/cakes.jpg"}, {"name":"Lorem Ipsum", "desc":"Lorem Ipsum", "desc2":"Lorem Ipsum", "price":"Lorem Ipsum", "picture":"images/cakes.jpg"}, {"name":"Lorem Ipsum", "desc":"Lorem Ipsum", "desc2":"Lorem Ipsum", "price":"Lorem Ipsum", "picture":"images/cakes.jpg"}]}');

    let menu = document.getElementById("orderTable");

    for(let item of shop_items.items){
		let entry = document.createElement("tr");
		
        let name = document.createElement("td");
        let desc = document.createElement("td");
		let price = document.createElement("td");
		
		let img = document.createElement("td");
		let picture = document.createElement("img");
		
		let quantity = document.createElement("td");
		let input = document.createElement("input");

        name.innerHTML = item.name;
		desc.innerHTML = item.desc;
		desc.colSpan = "2";
        price.innerHTML = item.price;
		
		picture.setAttribute('src', item.picture);
		picture.alt = "Pinkest Power";
		picture.id = "orderImage";
		img.appendChild(picture);
		
		input.type = "number";
		input.min = "1";
		input.max = "12";
		quantity.appendChild(input)
		
		
        entry.appendChild(name);
		entry.appendChild(price);
		entry.appendChild(desc);
		entry.appendChild(img);
		entry.appendChild(quantity);
		
		menu.appendChild(entry);

    };
}